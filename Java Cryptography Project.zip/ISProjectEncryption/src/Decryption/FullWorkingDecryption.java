package Decryption;

import java.security.MessageDigest;
import java.util.*;

public class FullWorkingDecryption {

    public void decryptMessage() throws Exception {
        Scanner sc = new Scanner(System.in);

        //Input Section
        System.out.print("Enter the Cipher Text: ");
        String cipherText = sc.nextLine().trim();

        System.out.print("Enter the SHA-256 hash of the cipher text: ");
        String expectedHash = sc.nextLine().trim();

        System.out.print("Enter the encryption key: ");
        int key = sc.nextInt(); sc.nextLine();

        System.out.print("Enter the Hint Chunk (code lengths): ");
        String hintChunk = sc.nextLine().trim();

        System.out.print("Enter the number of unique Huffman codes: ");
        int n = sc.nextInt(); sc.nextLine();

        Map<String, Character> huffmanCodeMap = new HashMap<>();
        System.out.println("Enter Huffman code and its character (e.g., 110 S):");
        for (int i = 0; i < n; i++) {
            String[] entry = sc.nextLine().trim().split("\\s+");
            huffmanCodeMap.put(entry[0], entry[1].charAt(0));
        }

        // Step 1: Hash Verification
        System.out.println("\n=== STEP 1: Verifying Hash ===");
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(cipherText.getBytes());
        StringBuilder calculatedHash = new StringBuilder();
        for (byte b : hashBytes) {
            calculatedHash.append(String.format("%02x", b));
        }

        if (!calculatedHash.toString().equalsIgnoreCase(expectedHash)) {
            System.out.println("❌ ERROR: Hash mismatch! Cipher text may have been tampered with.");
            return;
        } else {
            System.out.println("✅ Hash verified successfully.");
        }

        // Step 2: Break cipher text into 3-digit chunks
        System.out.println("\n=== STEP 2: Extracting 3-Digit Cipher Chunks ===");
        List<Integer> cipherChunks = new ArrayList<>();
        for (int i = 0; i < cipherText.length(); i += 3) {
            String chunk = cipherText.substring(i, i + 3);
            cipherChunks.add(Integer.parseInt(chunk));
        }
        System.out.println("Cipher Chunks: " + cipherChunks);

        // Step 3: Decrypt Chunks using Modular Subtraction
        System.out.println("\n=== STEP 3: Decrypted Decimal Chunks ===");
        List<String> decryptedChunks = new ArrayList<>();
        for (int c : cipherChunks) {
            int original = (c - key + 1000) % 1000;
            decryptedChunks.add(String.format("%03d", original));
        }
        System.out.println("Decrypted Decimal Chunks: " + decryptedChunks);

        // Step 4: Reconstruct binary string from decimal chunks
        System.out.println("\n=== STEP 4: 3-Bit Binary Chunks ===");
        StringBuilder fullBinary = new StringBuilder();
        for (String chunk : decryptedChunks) {
            for (char digit : chunk.toCharArray()) {
                int val = Character.getNumericValue(digit);
                fullBinary.append(String.format("%3s", Integer.toBinaryString(val)).replace(' ', '0'));
            }
        }
        System.out.println("Reconstructed Binary String: " + fullBinary);

        // Step 5: Huffman Decoding using Hint Chunk
        System.out.println("\n=== STEP 5: Huffman Decoding using Hint Chunk ===");
        List<String> binaryCodeWords = new ArrayList<>();
        int index = 0;
        for (char lenChar : hintChunk.toCharArray()) {
            int len = Character.getNumericValue(lenChar);
            if (len == 0) {
                binaryCodeWords.add(" "); // Add space marker directly
            } else {
                String code = fullBinary.substring(index, index + len);
                binaryCodeWords.add(code);
                index += len;
            }
        }

        StringBuilder originalMessage = new StringBuilder();
        for (String code : binaryCodeWords) {
            if (code.equals(" ")) {
                originalMessage.append(" ");
            } else if (huffmanCodeMap.containsKey(code)) {
                originalMessage.append(huffmanCodeMap.get(code));
            } else {
                System.out.println("⚠️ Warning: Unknown code found -> " + code);
                originalMessage.append('?');
            }
        }

        System.out.println("Original Message: " + originalMessage.toString());
    }
}