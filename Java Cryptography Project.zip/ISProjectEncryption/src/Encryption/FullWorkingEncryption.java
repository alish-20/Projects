package Encryption;

import java.util.*;
import java.security.MessageDigest;

public class FullWorkingEncryption {

    // Node class for Huffman tree
    static class Node implements Comparable<Node> {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
        }

        Node(int freq, Node left, Node right) {
            this.freq = freq;
            this.left = left;
            this.right = right;
        }

        public int compareTo(Node o) {
            return this.freq - o.freq;
        }

        boolean isLeaf() {
            return (left == null && right == null);
        }
    }

    // Recursive function to generate Huffman codes
    static void generateCodes(Node root, String code, Map<Character, String> huffmanCodes) {
        if (root == null) return;
        if (root.isLeaf()) {
            huffmanCodes.put(root.ch, !code.isEmpty() ? code : "0");
        }
        generateCodes(root.left, code + "0", huffmanCodes);
        generateCodes(root.right, code + "1", huffmanCodes);
    }

    public void encryptMessage() throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your message: ");
        String message = sc.nextLine().toUpperCase().replaceAll("[^A-Z0-9 &@%$!#?]", "");

        System.out.print("Select any 2 or 3 digit key for encryption: ");
        int key = sc.nextInt();

        // STEP 1: Frequency and probability
        System.out.println("\n=== STEP 1: Frequency and Probability ===");
        Map<Character, Integer> freqMap = new HashMap<>();
        for (char c : message.toCharArray()) {
            if (c != ' ') {
                freqMap.put(c, freqMap.getOrDefault(c, 0) + 1);
            }
        }

        int totalChars = message.length();
        for (Map.Entry<Character, Integer> entry : freqMap.entrySet()) {
            double prob = (double) entry.getValue() / totalChars;
            System.out.printf("Character: %c  Frequency: %d  Probability: %.3f%n",
                    entry.getKey(), entry.getValue(), prob);
        }

        // STEP 2: Build Huffman Tree
        System.out.println("\n=== STEP 2: Building Huffman Tree ===");
        PriorityQueue<Node> pq = new PriorityQueue<>();
        for (Map.Entry<Character, Integer> entry : freqMap.entrySet()) {
            pq.add(new Node(entry.getKey(), entry.getValue()));
        }

        while (pq.size() > 1) {
            Node left = pq.poll();
            Node right = pq.poll();
            assert right != null;
            Node parent = new Node(left.freq + right.freq, left, right);
            pq.add(parent);
        }
        Node root = pq.poll();
        System.out.println("Huffman tree built successfully.");

        // STEP 3: Generate Huffman Codes
        System.out.println("\n=== STEP 3: Huffman Codes ===");
        Map<Character, String> huffmanCodes = new HashMap<>();
        generateCodes(root, "", huffmanCodes);
        for (Map.Entry<Character, String> entry : huffmanCodes.entrySet()) {
            System.out.println(entry.getValue() +" " +entry.getKey() );
        }


        // STEP 4: Hint Generation (Code Lengths)
        System.out.println("\n=== STEP 4: Hint Sequence (Huffman Code Lengths) ===");
        StringBuilder hint = new StringBuilder();
        for (char ch : message.toCharArray()) {
            if (ch == ' ') {
                hint.append("0");
            } else {
                hint.append(huffmanCodes.get(ch).length());
            }
        }
        System.out.println("Hint Chunk: " + hint);


        // STEP 5: Encode the Message
        System.out.println("\n=== STEP 5: Huffman Encoded Binary ===");
        StringBuilder encodedBinary = new StringBuilder();
        for (char ch : message.toCharArray()) {
            if (ch != ' ') {
                encodedBinary.append(huffmanCodes.get(ch));
            }
        }
        System.out.println("Binary: " + encodedBinary);

        // STEP 6: Convert to 3-digit Binary Chunks
        System.out.println("\n=== STEP 6: 3-Digit Binary Chunks ===");
        String encodedString = encodedBinary.toString();

        // Calculate the number of padding zeros needed
        int length = encodedString.length();
        int paddingNeeded = (3 - (length % 3)) % 3; // Calculate padding needed to make length a multiple of 3

        // Pad the encoded string with zeros if necessary
        StringBuilder paddedBinary = new StringBuilder(encodedString);
        for (int i = 0; i < paddingNeeded; i++) {
            paddedBinary.append('0'); // Append zeros to the end
        }

        // Now, split the padded binary string into 3-digit chunks
        List<String> chunks = new ArrayList<>();
        for (int i = 0; i < paddedBinary.length(); i += 3) {
            String chunk = paddedBinary.substring(i, Math.min(i + 3, paddedBinary.length()));
            chunks.add(chunk);
        }

        // Print the 3-digit chunks
        System.out.println("Padded Binary: " + paddedBinary);
        System.out.println("3-Digit Chunks:");
        for (String chunk : chunks) {
            System.out.print(chunk);
            System.out.print(" ");
        }
        System.out.println();

        // STEP 7: Convert Chunks to Decimal
        System.out.println("\n=== STEP 7: Decimal Message ===");
        List<Integer> decimalValues = new ArrayList<>();
        System.out.println("Decimal Message: ");
        for (String chunk : chunks) {
            int decimal = Integer.parseInt(chunk, 2);
            decimalValues.add(decimal);
            System.out.print(decimal);
        }
        System.out.println();

        //Break Decimal Message into 3-digit Decimal Chunks
        StringBuilder decimalMsg = new StringBuilder();
        decimalValues.forEach(decimalMsg::append);

        // Pad with zeros if needed
        while (decimalMsg.length() % 3 != 0) decimalMsg.append("0");

        List<String> decimalChunks = new ArrayList<>();
        for (int i = 0; i < decimalMsg.length(); i += 3) {
            decimalChunks.add(decimalMsg.substring(i, i + 3));
        }

        System.out.println("3-Digit Chunks:");
        decimalChunks.forEach(chunk -> System.out.print(chunk + " "));
        System.out.println();

        // STEP 8: Modular Encryption ((M + k) mod 1000)
        System.out.println("\n=== STEP 8: Encrypted Cipher Chunks ===");

        List<String> cipherChunks = new ArrayList<>();
        for (String chunk : decimalChunks) {
            int m = Integer.parseInt(chunk);
            int cipher = (m + key) % 1000;
            cipherChunks.add(String.format("%03d", cipher)); // keep 3-digit format
        }

        System.out.println("Cipher Chunks:");
        cipherChunks.forEach(c -> System.out.print(c + " "));
        System.out.println();
        StringBuilder finalCipherText = new StringBuilder();
        cipherChunks.forEach(finalCipherText::append);

        System.out.println("Cipher Text: " + finalCipherText.toString());

        // STEP 9: SHA-256 Hash of Cipher Text
        System.out.println("\n=== STEP 9: SHA-256 Hash of Cipher Text ===");
        MessageDigest digest = MessageDigest.getInstance("SHA-256");

        byte[] hashBytes = digest.digest(finalCipherText.toString().getBytes());
        StringBuilder hashHex = new StringBuilder();
        for (byte b : hashBytes) {
            hashHex.append(String.format("%02x", b));
        }
        System.out.println("SHA-256 Hash: " + hashHex);
    }
}