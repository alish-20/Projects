import Decryption.FullWorkingDecryption;
import Encryption.FullWorkingEncryption;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        select();
        }
    public static void select() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose an option:");
        System.out.println("1. Encrypt");
        System.out.println("2. Decrypt");
        System.out.println("3. Exit");
        int choice = sc.nextInt();
        if (choice == 1) {
            FullWorkingEncryption encryption = new FullWorkingEncryption();
            encryption.encryptMessage();
            select();
        } else if (choice == 2) {
            FullWorkingDecryption decryption = new FullWorkingDecryption();
            decryption.decryptMessage();
            select();
        }else if (choice == 3) {
            System.out.println("Exiting...");
        } else {
            System.out.println("Invalid choice.");
            select();
        }
    }
}