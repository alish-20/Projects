package com.ecommerce.alishba.controller;

import org.springframework.beans.factory.annotation.Autowired;
import com.ecommerce.alishba.services.UpdateProductService;
import com.ecommerce.alishba.DTO.UpdateProductResponse;
import com.ecommerce.alishba.DTO.UpdateProductRequest;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UpdateProductController {

    @Autowired
    private UpdateProductService updateProductService;

    @PutMapping(path = "/api/product/UpdateProduct")
    public UpdateProductResponse updateProduct(@RequestBody UpdateProductRequest updateProductBody) {
        return updateProductService.updateProduct(updateProductBody);
    }
}
