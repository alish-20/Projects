package com.ecommerce.alishba.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteUserRequest {
    private Integer userId;
}
