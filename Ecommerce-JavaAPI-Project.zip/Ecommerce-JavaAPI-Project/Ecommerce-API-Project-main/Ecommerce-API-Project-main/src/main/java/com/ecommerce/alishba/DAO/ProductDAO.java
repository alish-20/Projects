package com.ecommerce.alishba.DAO;

import com.ecommerce.alishba.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDAO extends JpaRepository<Product, Integer>{


}
