package com.ecommerce.afifa.Utils;

public class JavaUtils {

    public static boolean isNotNull(Object obj) {
        return null!=obj;
    }
}
