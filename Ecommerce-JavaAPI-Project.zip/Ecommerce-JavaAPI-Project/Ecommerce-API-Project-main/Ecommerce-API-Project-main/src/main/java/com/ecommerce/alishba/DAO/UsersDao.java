package com.ecommerce.alishba.DAO;

import com.ecommerce.alishba.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UsersDao extends JpaRepository<Users, Integer>{

    Users findByLoginName(String loginName);

}