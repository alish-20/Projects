package com.ecommerce.alishba.controller;

import com.ecommerce.alishba.DTO.InventoryItemRequest;
import com.ecommerce.alishba.DTO.InventoryItemResponse;
import com.ecommerce.alishba.services.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/inventory/create")
public class CreateInventoryController {
    private final InventoryService inventoryService;

    @Autowired
    public CreateInventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @PostMapping
    public ResponseEntity<InventoryItemResponse> addItem(@RequestBody InventoryItemRequest itemDTO) {
        InventoryItemResponse addedItem = inventoryService.addInventoryItem(itemDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(addedItem);
    }
}
