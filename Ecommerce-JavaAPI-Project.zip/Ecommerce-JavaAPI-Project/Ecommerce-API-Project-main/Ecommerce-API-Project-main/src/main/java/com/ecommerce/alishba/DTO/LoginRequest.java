package com.ecommerce.alishba.DTO;


public class LoginRequest {

    public String loginName;
    public String password;
}
