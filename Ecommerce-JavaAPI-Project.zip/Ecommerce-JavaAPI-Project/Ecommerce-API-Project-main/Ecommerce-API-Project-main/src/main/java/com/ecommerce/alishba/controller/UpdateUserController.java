package com.ecommerce.alishba.controller;

import com.ecommerce.alishba.DTO.UpdateUserRequest;
import com.ecommerce.alishba.DTO.UpdateUserResponse;
import com.ecommerce.alishba.services.UpdateUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UpdateUserController {

    @Autowired
    private UpdateUserService updateUserService;

    @PutMapping("/api/Updateuser/{userId}")
    public ResponseEntity<UpdateUserResponse> updateUser(
            @PathVariable Integer userId,
            @RequestBody UpdateUserRequest userRequest) {

        UpdateUserResponse response = updateUserService.updateUser(userId, userRequest);
        return ResponseEntity.ok(response);  // Returning the updated response
    }
}
