package com.ecommerce.alishba.DTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeleteUserResponse {

    private String errorCode;
    private String message;

}
