package com.ecommerce.alishba.DTO;

import lombok.Data;

@Data
public class CartItemUpdateRequestDTO {
    private Integer productId;
    private int quantity;
}
