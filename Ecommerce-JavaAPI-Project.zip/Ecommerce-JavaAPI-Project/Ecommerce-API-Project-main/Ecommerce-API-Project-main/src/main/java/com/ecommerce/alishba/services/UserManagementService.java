package com.ecommerce.alishba.services;

import java.sql.SQLException;
import java.util.List;
import com.ecommerce.alishba.model.Users;
import com.ecommerce.alishba.DAO.UsersDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserManagementService {

    @Autowired
    UsersDao user;

    public List<Users> getAllUser() throws SQLException{

        return user.findAll();
    }

    public Users getUserById(Integer userId){
        return user.findById(userId).get();
    }
}
